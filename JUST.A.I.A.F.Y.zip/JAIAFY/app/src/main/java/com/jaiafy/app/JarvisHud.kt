package com.jaiafy.app
import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.cos
import kotlin.math.sin

/** واجهة J.A.R.V.I.S: حلقات متحدة المركز، شريط أزرق عريض، قوس أصفر، وشبكة تصميم في الخلفية. */
class JarvisHud(c: Context) : View(c) {
    private val t0 = System.nanoTime()
    private val st = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val fl = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val bg = Paint()
    private val tx = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
    }
    private val cyan = 0xFF5FE3FF.toInt()

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        bg.shader = LinearGradient(0f, 0f, 0f, h.toFloat(),
            intArrayOf(0xFF02070D.toInt(), 0xFF04202F.toInt(), 0xFF021018.toInt()), null, Shader.TileMode.CLAMP)
    }

    private fun arc(cv: Canvas, cx: Float, cy: Float, r: Float, start: Float, sweep: Float,
                    width: Float, color: Int, dash: FloatArray? = null) {
        st.strokeWidth = width; st.color = color
        st.pathEffect = dash?.let { DashPathEffect(it, 0f) }
        cv.drawArc(cx - r, cy - r, cx + r, cy + r, start, sweep, false, st)
        st.pathEffect = null
    }

    override fun onDraw(cv: Canvas) {
        val t = (System.nanoTime() - t0) / 1e9f
        val w = width.toFloat(); val h = height.toFloat()
        val cx = w / 2f; val cy = h / 2f
        val R = minOf(w, h) * 0.46f
        cv.drawRect(0f, 0f, w, h, bg)

        // شبكة التصميم
        st.strokeWidth = 1f; st.color = 0x145FE3FF; st.pathEffect = null
        var gx = 0f; while (gx < w) { cv.drawLine(gx, 0f, gx, h, st); gx += 48f }
        var gy = 0f; while (gy < h) { cv.drawLine(0f, gy, w, gy, st); gy += 48f }

        // الحلقة الخارجية (أقواس متقطعة)
        arc(cv, cx, cy, R, t * 10f, 110f, 10f, 0x335FE3FF)
        arc(cv, cx, cy, R, t * 10f, 110f, 3f, cyan)
        arc(cv, cx, cy, R, t * 10f + 130f, 100f, 3f, cyan)
        arc(cv, cx, cy, R, t * 10f + 250f, 90f, 3f, cyan)

        // حلقة العلامات
        st.strokeWidth = 2f; st.color = 0xCC5FE3FF.toInt()
        for (i in 0 until 120) {
            val a = Math.toRadians((i * 3f - t * 4f).toDouble())
            val r1 = R * 0.92f; val r2 = r1 + R * (if (i % 5 == 0) 0.05f else 0.025f)
            cv.drawLine(cx + (r1 * cos(a)).toFloat(), cy + (r1 * sin(a)).toFloat(),
                cx + (r2 * cos(a)).toFloat(), cy + (r2 * sin(a)).toFloat(), st)
        }

        // الشريط الأزرق العريض
        val seg = floatArrayOf(R * 0.06f, R * 0.012f)
        arc(cv, cx, cy, R * 0.79f, 140f + t * 6f, 220f, R * 0.13f, 0xCC1E88E5.toInt(), seg)
        arc(cv, cx, cy, R * 0.79f, t * 50f, 36f, R * 0.07f, 0xCC8FE9FF.toInt(), seg)
        arc(cv, cx, cy, R * 0.865f, 0f, 360f, 2f, 0x885FE3FF.toInt())
        arc(cv, cx, cy, R * 0.715f, 0f, 360f, 2f, 0x885FE3FF.toInt())

        // القوس الأصفر والنقاط
        arc(cv, cx, cy, R * 0.66f, 200f + sin(t) * 8f, 75f, 5f, 0xFFFFB300.toInt())
        arc(cv, cx, cy, R * 0.66f, 285f, 22f, 2f, 0x99FFB300.toInt())
        fl.color = 0xFFFFD54F.toInt()
        for (i in 0 until 6) {
            val a = Math.toRadians((245f + i * 7f).toDouble())
            cv.drawCircle(cx + (R * 0.88f * cos(a)).toFloat(), cy + (R * 0.88f * sin(a)).toFloat(), 3f, fl)
        }

        // الدائرة الداخلية
        fl.shader = null; fl.color = 0xDD031624.toInt()
        cv.drawCircle(cx, cy, R * 0.58f, fl)
        arc(cv, cx, cy, R * 0.58f, 0f, 360f, 3f, 0xCC5FE3FF.toInt())
        arc(cv, cx, cy, R * 0.5f, -t * 25f, 360f, 2f, 0x995FE3FF.toInt(), floatArrayOf(R * 0.03f, R * 0.03f))
        arc(cv, cx, cy, R * 0.42f, 0f, 360f, 1f, 0x555FE3FF.toInt())
        st.strokeWidth = 1f; st.color = 0x335FE3FF
        for (i in 0 until 24) {
            val a = Math.toRadians((i * 15f + t * 3f).toDouble())
            cv.drawLine(cx + (R * 0.42f * cos(a)).toFloat(), cy + (R * 0.42f * sin(a)).toFloat(),
                cx + (R * 0.58f * cos(a)).toFloat(), cy + (R * 0.58f * sin(a)).toFloat(), st)
        }

        // توهج خلف النص
        val pulse = 1f + 0.05f * sin(t * 3f)
        fl.shader = RadialGradient(cx, cy, R * 0.45f * pulse,
            intArrayOf(0x555FE3FF, 0x00000000), null, Shader.TileMode.CLAMP)
        cv.drawCircle(cx, cy, R * 0.45f * pulse, fl)
        fl.shader = null

        // النص
        val name = "J.A.I.A.F.Y."
        tx.textSize = R * 0.2f
        tx.textSize = tx.textSize * (R * 0.95f / tx.measureText(name))
        tx.color = Color.WHITE; tx.setShadowLayer(R * 0.08f, 0f, 0f, cyan)
        cv.drawText(name, cx, cy + tx.textSize / 3f, tx)
        tx.clearShadowLayer(); tx.color = cyan; tx.textSize = R * 0.09f
        cv.drawText("جايفاي", cx, cy + R * 0.24f, tx)

        postInvalidateOnAnimation()
    }
}
