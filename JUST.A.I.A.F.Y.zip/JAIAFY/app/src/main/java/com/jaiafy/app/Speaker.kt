package com.jaiafy.app
import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

/** نطق عربي بنبرة منخفضة وهادئة (صوت جارفيس الأصلي محمي، فنستخدم صوت TTS عربي بنبرة قريبة). */
class Speaker(ctx: Context) {
    private var ready = false
    private val tts: TextToSpeech = TextToSpeech(ctx) {
        if (it == TextToSpeech.SUCCESS) {
            tts.language = Locale("ar"); tts.setPitch(0.75f); tts.setSpeechRate(0.95f); ready = true
        }
    }
    fun say(text: String, onDone: () -> Unit = {}) {
        if (!ready) { onDone(); return }
        tts.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { onDone() }
            @Deprecated("") override fun onError(id: String?) { onDone() }
        })
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jaiafy")
    }
    fun shutdown() { tts.shutdown() }
}
