package com.jaiafy.app
import android.content.Context
import android.util.Base64
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** العقل: يرسل كلامك (وصورة الكاميرا إن وُجدت) إلى OpenRouter ويرجع رد + أوامر تنفيذ. */
object Brain {
    private const val DEFAULT_MODEL = "anthropic/claude-sonnet-4.5"
    private const val SYSTEM = """أنت جايفاي (J.A.I.A.F.Y)، مساعد ذكي بأسلوب جارفيس، تخاطب المستخدم بـ"سيدي" بالعربية الفصحى المبسطة وبإيجاز.
أجب دائماً بـ JSON فقط: {"say":"ما تنطقه","actions":[{"type":"...","arg":"..."}]}
أنواع الأوامر: open_app(اسم التطبيق), click_text(نص على الشاشة), type_text, back, home, recents, scroll_down, scroll_up,
search_web(نص), open_url(رابط), call(رقم), flashlight_on, flashlight_off, volume_up, volume_down, bt_list, usb_list, look, remember(معلومة).
استخدم look عندما يطلب المستخدم أن ترى أو تصف ما أمام الكاميرا."""

    private fun prefs(c: Context) = EncryptedSharedPreferences.create(c, "secure",
        MasterKey.Builder(c).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
    fun saveKey(c: Context, k: String) = prefs(c).edit().putString("key", k.trim()).apply()
    fun saveModel(c: Context, m: String) = prefs(c).edit().putString("model", m.trim()).apply()
    fun model(c: Context) = prefs(c).getString("model", "")?.ifBlank { null } ?: DEFAULT_MODEL

    /** OpenRouter: واجهة متوافقة مع OpenAI، تدعم أي نموذج (Claude, GPT, Gemini...). */
    fun ask(c: Context, text: String, memory: String, jpeg: ByteArray? = null): JSONObject {
        val content = JSONArray()
        content.put(JSONObject().put("type", "text").put("text", text))
        jpeg?.let { content.put(JSONObject().put("type", "image_url").put("image_url",
            JSONObject().put("url", "data:image/jpeg;base64," + Base64.encodeToString(it, Base64.NO_WRAP)))) }
        val body = JSONObject().put("model", model(c)).put("max_tokens", 600)
            .put("messages", JSONArray()
                .put(JSONObject().put("role", "system").put("content", SYSTEM + "\nذاكرة المستخدم:\n" + memory))
                .put(JSONObject().put("role", "user").put("content", content)))
        val con = URL("https://openrouter.ai/api/v1/chat/completions").openConnection() as HttpURLConnection
        con.requestMethod = "POST"; con.doOutput = true
        con.setRequestProperty("Content-Type", "application/json")
        con.setRequestProperty("Authorization", "Bearer " + prefs(c).getString("key", ""))
        con.setRequestProperty("X-Title", "JAIAFY")
        con.outputStream.use { it.write(body.toString().toByteArray()) }
        val resp = (if (con.responseCode < 300) con.inputStream else con.errorStream).bufferedReader().readText()
        return try {
            val t = JSONObject(resp).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
            JSONObject(t.substring(t.indexOf('{'), t.lastIndexOf('}') + 1))
        } catch (e: Exception) { JSONObject().put("say", "عذراً سيدي، تعذر الاتصال بالعقل.").put("actions", JSONArray()) }
    }
}
