package com.jaiafy.app
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.graphics.ImageFormat
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import java.io.ByteArrayOutputStream

/** خدمة تعمل بالخلفية: تصفيقتان → "تفضل سيدي" → استماع → عقل → تنفيذ → نطق. */
class JarvisService : LifecycleService() {
    private val main = Handler(Looper.getMainLooper())
    private lateinit var speaker: Speaker
    private lateinit var mem: Memory
    private lateinit var actions: Actions
    private lateinit var clap: ClapDetector
    private var recognizer: SpeechRecognizer? = null
    private val capture = ImageCapture.Builder().build()

    override fun onCreate() {
        super.onCreate()
        val ch = NotificationChannel("jaiafy", "جايفاي", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        startForeground(1, Notification.Builder(this, "jaiafy").setContentTitle("جايفاي يستمع للتصفيق")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).build())
        speaker = Speaker(this); mem = Memory(this); actions = Actions(this, mem)
        clap = ClapDetector { main.post { onWake() } }
        clap.start()
        ProcessCameraProvider.getInstance(this).also { f -> f.addListener({
            try { f.get().bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, capture) } catch (_: Exception) {}
        }, ContextCompat.getMainExecutor(this)) }
    }

    private fun onWake() = speaker.say("تفضل سيدي") { main.post { listen() } }

    private fun listen() {
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(r: android.os.Bundle?) {
                    val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (t.isNullOrBlank()) rearm() else think(t)
                }
                override fun onError(e: Int) = rearm()
                override fun onReadyForSpeech(p: android.os.Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: android.os.Bundle?) {}
                override fun onEvent(t: Int, p: android.os.Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-SA"))
        }
    }

    private fun think(text: String, jpeg: ByteArray? = null) {
        Thread {
            val r = Brain.ask(this, text, mem.all(), jpeg)
            val acts = r.optJSONArray("actions")
            var say = r.optString("say")
            var wantsLook = false
            if (acts != null) for (i in 0 until acts.length()) {
                val a = acts.getJSONObject(i)
                if (a.optString("type") == "look") wantsLook = true
                else actions.run(a)?.let { say += "。$it" }
            }
            if (wantsLook && jpeg == null) main.post { snapshot { think(text, it) } }
            else main.post { speaker.say(say) { rearm() } }
        }.start()
    }

    private fun snapshot(cb: (ByteArray) -> Unit) {
        capture.takePicture(ContextCompat.getMainExecutor(this), object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(img: ImageProxy) {
                val b = ByteArray(img.planes[0].buffer.remaining()); img.planes[0].buffer.get(b)
                val fmt = img.format; img.close()
                if (fmt == ImageFormat.JPEG) cb(b) else speaker.say("تعذر التقاط الصورة") { rearm() }
            }
            override fun onError(e: ImageCaptureException) { speaker.say("تعذر فتح الكاميرا") { rearm() } }
        })
    }

    private fun rearm() { recognizer?.destroy(); clap.start() }

    override fun onDestroy() { clap.stop(); recognizer?.destroy(); speaker.shutdown(); super.onDestroy() }
}
