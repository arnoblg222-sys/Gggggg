package com.jaiafy.app
import android.Manifest
import android.content.Intent
import android.provider.Settings
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity

class MainActivity : FragmentActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        // قفل الوجه: يعتمد على بصمة الوجه المسجلة في نظام الجهاز (أأمن من أي تعرف مخصص).
        val ok = BiometricManager.from(this).canAuthenticate(
            BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL)
        if (ok != BiometricManager.BIOMETRIC_SUCCESS) { buildUi(); return }
        BiometricPrompt(this, ContextCompat.getMainExecutor(this), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(r: BiometricPrompt.AuthenticationResult) = buildUi()
            override fun onAuthenticationError(c: Int, m: CharSequence) = finish()
        }).authenticate(BiometricPrompt.PromptInfo.Builder().setTitle("جايفاي")
            .setSubtitle("تحقق من هويتك بالوجه")
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL).build())
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(48, 48, 48, 48)
            setBackgroundColor(0xFF04121F.toInt()) }
        fun tv(t: String) = TextView(this).apply { text = t; setTextColor(0xFF4FD8FF.toInt()); textSize = 18f; gravity = Gravity.CENTER }
        val key = EditText(this).apply { hint = "مفتاح OpenRouter (sk-or-...)"; inputType = InputType.TYPE_TEXT_VARIATION_PASSWORD; setTextColor(-1); setHintTextColor(0xFF668899.toInt()) }
        val model = EditText(this).apply { hint = "النموذج (اتركه فارغاً للافتراضي)"; setTextColor(-1); setHintTextColor(0xFF668899.toInt()) }
        root.addView(JarvisHud(this), LinearLayout.LayoutParams(-1, 0, 1f));  root.addView(key); root.addView(model)
        root.addView(Button(this).apply { text = "١) حفظ المفتاح والنموذج"; setOnClickListener { Brain.saveKey(this@MainActivity, key.text.toString()); Brain.saveModel(this@MainActivity, model.text.toString()) } })
        root.addView(Button(this).apply { text = "٢) تفعيل التحكم بالشاشة"; setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } })
        root.addView(Button(this).apply { text = "٣) تشغيل جايفاي"; setOnClickListener {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA, Manifest.permission.POST_NOTIFICATIONS,
                Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.CALL_PHONE), 1)
            ContextCompat.startForegroundService(this@MainActivity, Intent(this@MainActivity, JarvisService::class.java)) } })
        root.addView(tv("\nصفّق مرتين لتفعيله"))
        setContentView(root)
    }
}
